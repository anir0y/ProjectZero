# How you can Contribute.
Its very simple, create a challenge or use existing github code add new modules. send a pull request, I'll add them.

## What we looking ?

We need challenges that should be easy to pwn, as this module is going to used for people who don't understand things. we need to have this thing as simple as possible.

## Future Plans 

thinking of having another project (maybe with docker support) with mid level challenges. including some real life challenges. 
Secure web-Apps with mis-configs, or outdated pf-sense and others. 

# Agenda 
My agenda is very simple, make something that can help our next generation to learn better. we are ruling cyber space today so let's help out next gen to shine brighter than us. 

### Issues with Pull requests?
You can DM me anytime for any kind of assistance. here is my [twitter](https://www.twitter.com/anir0y)

#### I want to learn from a real person.
Sure. you can DM me, let's talk! 

