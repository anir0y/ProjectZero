<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Product Manager </title>
</head>
<body>
<?php include "home.php"; ?>
<div class="xss2" center>
<h2><center>About this challenge:(FBCTF 2019) </h2></center>
<p><em>Come play with our products manager application!

Written by Vampire/p>

This problem does not require any brute force or scanning. </em><p>
<a href="product/">click here</a> to Play!</p>
</center>



</body>
</html>
<?php include "footer.php"; ?>
