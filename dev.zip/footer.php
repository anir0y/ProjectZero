<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  position: fixed;
  bottom: 0;
  left:0;
  width: 100%;
  text-align: center;
  background-color: none;
  text-align: center;
  color: white;

}

</style>
</head>
<body>



<footer>
  <img src="https://madewithlove.now.sh/in?heart=true&colorA=%23303655&template=for-the-badge" alt="Made with love in India">
</footer>

</body>
</html>
