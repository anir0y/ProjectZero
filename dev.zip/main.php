<?php include "home.php"; ?>

<html>
<head>
<title>Dashboard</title>
<link href="css/dashboard.css" rel=stylesheet>
</head>
<body>
<center><h1>ALPHA RELEASE OF 'PROJECT ZERO'!</h1></center>
<hr style="color:blue"></hr>
<h3>Send us your feedback and suggestions here:</h3>
<br></br>

</body>
</html>
<?php include("footer.php"); ?>
