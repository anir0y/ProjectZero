# ProjectZero
>> This #Summer #internship training program I developed one very simple web-app that can be exploited easily.   
my motive behind this to encourage new #generation learn more about things(in manual ways) rather than using tools (available on internet).
surprisingly some of my students came with some new ideas too. Thinking to add some of them (Condition is they have to write those #codes).   

PS: this is very easy to exploit. so if you have basic idea about how SQLi, Bruteforce, LFI, RFI works, you can get into this box easily. (yes! you can pwn this in many different ways).   




Update: https://lnkd.in/f8Vg5rW (YouTube)

# summerTraining CyberSecurity 2019

## If you want to contribute feel free to send a pull request or DM me :)

> together we can make it happen!
