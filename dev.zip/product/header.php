<html>
  <head>
    <title>Products Manager</title>
    <link href="css/ch-1.css" rel="stylesheet">
  </head>
  <body>
    <h2>Welcome to products manager!</h2>
    <p>
      Links:
      <ul>
        <li><a href="/product/">View</a> top 5 products</li>
        <li><a href="/product/add.php">Add</a> your own product</li>
        <li><a href="/product/view.php">View</a> details of your own product</li>
      </ul>
    </p>
