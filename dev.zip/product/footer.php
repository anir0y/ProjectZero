<link href="css/footer.css" rel="stylesheet">
<footer>
  <div class="footer">
<em>About this challenge:(FBCTF 2019)</em>
<p>Come play with our products manager application!<p>
<p>Written by Vampire/p><p>
This problem does not require any brute force or scanning.
</p>

  </div>
</footer>
</body>
</html>

